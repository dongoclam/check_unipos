const USERS_PATH = "/users/"
const ADMIN_USERS_PATH = "/admin/users/"
const ADMIN_CLONES_USERS_PATH = "/admin/clones/users"
const ADMIN_UPDATES_USERS_PATH = "/admin/updates/users"

const ADMIN_CHATWORK_USERS_PATH = "/admin/chatwork_users/"
const ADMIN_CLONES_CHATWORK_USERS_PATH = "/admin/clones/chatwork_users"

const ADMIN_CLONES_UNIPOES_PATH = "/admin/clones/uniposes"

const ADMIN_SETTINGS_PATH = "/admin/settings/"
const ADMIN_NEW_SETTING_PATH = "/admin/settings/new"

const ADMIN_TAGS_PATH = "/admin/tags/"
const ADMIN_NEW_TAG_PATH = "/admin/tags/new"
;
