$(document).ready(function() {
  $(".tab-content").toggleClass("invisible");
  $("#sent, #clapped").toggleClass("active");
});
